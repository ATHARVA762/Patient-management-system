package com.healthcareapp.service;

import com.healthcareapp.model.Patient;

import java.util.List;

public interface PatientService {
    List<Patient> getAllPatients();
    Patient savePatient(Patient patient);
    Patient getPatientById(Long id);
    Patient updatePatient(Long id, Patient patient);
    void deletePatient(Long id); // Add this method
}
