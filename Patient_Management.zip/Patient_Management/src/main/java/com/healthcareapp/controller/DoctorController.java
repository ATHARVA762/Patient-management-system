package com.healthcareapp.controller;

import com.healthcareapp.model.Patient;
import com.healthcareapp.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Autowired
    private PatientService patientService;

    @GetMapping
    public String viewAllPatients(Model model) {
        List<Patient> patients = patientService.getAllPatients();
        model.addAttribute("patients", patients);
        return "doctor"; // Thymeleaf template name for doctor view
    }

    @GetMapping("/{id}")
    public String viewPatientHistory(@PathVariable Long id, Model model) {
        Patient patient = patientService.getPatientById(id);
        model.addAttribute("patient", patient);
        return "patientHistory"; // Thymeleaf template name for patient's history
    }

    @PostMapping("/{id}/update")
    public String updatePatientHistory(@PathVariable Long id, @ModelAttribute Patient patient) {
        patientService.updatePatient(id, patient);
        return "redirect:/doctor"; // Redirect to the doctor view after updating
    }
}
